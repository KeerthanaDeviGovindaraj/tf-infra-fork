const AWS = require("aws-sdk");
const ses = new AWS.SES();
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  console.log("SNS Event received:", JSON.stringify(event));

  for (const record of event.Records) {
    try {
      //Parse SNS message 
      const message = JSON.parse(record.Sns.Message);
      const { email, firstName, token } = message;

      console.log(`Processing verification email for: ${email}`);

      // Check for duplicate in DynamoDB 
      const existing = await dynamodb
        .get({
          TableName: process.env.DYNAMODB_TABLE,
          Key: { email },
        })
        .promise();

      if (existing.Item) {
        console.log(`Duplicate detected for ${email} — skipping.`);
        continue; 
      }

      //verification link 
      const verificationLink = `http://${process.env.APP_DOMAIN}/v1/user/verify-email?email=${encodeURIComponent(email)}&token=${token}`;

      //sending email using AWS SES
      await ses
        .sendEmail({
          Source: process.env.SES_FROM_EMAIL,
          Destination: {
            ToAddresses: [email],
          },
          Message: {
            Subject: {
              Data: "Verify your email address",
            },
            Body: {
              Text: {
                Data: `Hi ${firstName},\n\nPlease verify your email address by clicking the link below. This link is valid for 1 minute.\n\n${verificationLink}\n\nIf you did not create an account, please ignore this email.`,
              },
            },
          },
        })
        .promise();

      console.log(`Verification email sent to ${email}`);

      await dynamodb
        .put({
          TableName: process.env.DYNAMODB_TABLE,
          Item: {
            email,
            sentAt: new Date().toISOString(),
          },
        })
        .promise();

      console.log(`Email tracked in DynamoDB for ${email}`);
    } catch (err) {
      console.error(`Error processing record:`, err);
      throw err; 
    }
  }
};